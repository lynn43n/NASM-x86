#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

extern int assFunc(int x, int y);

char c_checkValidity(int x, int y){
    if(x<0)
        return '0';
    if(y<=0){
        return '0';
    }
    if(y>((int) pow((double) 2,15))){
        return '0';
    }
    return '1';
    
}


int main(int argc, char** argv){
    printf("%s","enter 2 numbers: ");
    int x;
    int y;
    
    if (scanf("%d%d", &x, &y) == 2){
        assFunc(x,y);
    }   
    
    
    return 0;
}

