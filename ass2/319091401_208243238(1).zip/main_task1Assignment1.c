#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#define	MAX_LEN 34			/* maximal input string size */
					/* enough to get 32-bit string + '\n' + null terminator */
extern int convertor(char* buf);

int main(int argc, char** argv)
{
    char buf[MAX_LEN ];
 
    fgets(buf, MAX_LEN, stdin);/* get user input string */
    char q[] = "q";
    char ans[32];
    while(buf[0]!=q[0]){
        if((strlen(buf)-1)<32){
            int i=0;
            while(i<32-(strlen(buf)-1)){
                ans[i]=0;
                i++;
            }
            while(i<32){
                ans[i]=buf[i-(32-(strlen(buf)-1))];
                i++;
            }
            convertor(ans);	
        }
        else{
            convertor(buf);
        }
        		/* call your assembly function */
        fgets(buf, MAX_LEN, stdin);/* get user input string */
    }
  return 0;
}
